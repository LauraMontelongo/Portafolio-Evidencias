#include <stdlib.h> 
#include <conio.h> 
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <locale.h>
#include <windows.h>
#include <iostream> 
#include <iomanip>
#include <fstream>
#include <sstream>

void gotoxy(int x,int y){ 
	HANDLE hcon; 
	hcon = GetStdHandle(STD_OUTPUT_HANDLE); 
	COORD dwPos; 
	dwPos.X = x; 
	dwPos.Y= y; 
	SetConsoleCursorPosition(hcon,dwPos); 
}
	
using namespace std;
FILE *file = NULL;

//ESTRUCTURAS PARA LOGIN
struct admin{
	char nombre[20];
	char contra[20];
	struct admin *siguiente;
    struct admin *anterior;
};

 struct usuario{
	char nombre[20];
	char contra[20];
	struct usuario *siguienteb;
    struct usuario *anteriorb;
};

struct admin *primero=NULL, *ultimo=NULL;
struct usuario *prim=NULL, *ult=NULL;
	
/*RUTAS*/
struct MenuRutas{
	char nombreRuta[30];
	char paradaRuta[30];
	char horarioRuta[30];
	char destinosRuta[30];
};
struct Rutas{
    int idRuta;
    int estado;
    string destino;
    string hora;
    string dia;
    string parada;
    Rutas *sigR;
}*primeroR, *ultimoR;

/*PASAJERO*/
struct Usuario{
	int idUsuario;
    Rutas *lista;
	Usuario *sig;
}*primLista,*ultLista;

#include "portada.h"
#include "validacion.h"
//#include "archivos.h"
#include "funciones.h"
#include "menus.h"
#include "login.h"
