void portada(){
	int aux = 0;
	FILE *archivo = fopen("portada.txt", "r");
	
	for(int i=0; i<63; i++){
		for(int j=0; j<75; j++){
			fscanf(archivo, "%d\t", &aux);
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), aux);
			printf("%c", 177);
		}
		printf("\n");
	}
	
	fclose(archivo);
}

void datos(){
	
	setlocale(LC_CTYPE, "Spanish");
	gotoxy(65, 35);
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),9);
	printf("Universidad Polit�cnica de San Luis Potos�");
	gotoxy(65, 37);
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),9);
	printf("Programaci�n II PROYECTO RUTAS");
	gotoxy(65, 39);
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),9);
	printf("- Cortes Beltran Carol Elizabeth - 177203");
	gotoxy(65, 41);
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),9);
	printf("- Montelongo Mart�nez Laura Ivon - 177291");
	gotoxy(65, 43);
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),9);
	printf("Presiona cualquier tecla para iniciar...");
	getch();
}
