void leerarchivo(){
	
	if(!(file=fopen("admin.txt", "r"))){				//Si el archivo no se puede abrir, se cierra el programa
		printf("Error al intentar leer el archivo");
		exit(1);
	}
	//leer del archivo, vaciar hacia un nodo
	while(!feof(file)){
		
		admin *nuevo = new admin;
		
		fscanf(file,"%s\t", nuevo->nombre);
		fscanf(file,"%s\n", nuevo->contra);
	
		if(primero==NULL){
			primero=nuevo;
			primero->siguiente=NULL;
			primero->anterior=NULL;
			ultimo=primero;
		}else{
			ultimo->siguiente=nuevo;
			nuevo->siguiente=NULL;
			nuevo->anterior=ultimo;
			ultimo=nuevo;
		}
		
	}
	fclose(file);
}

void leerarchivo2(){
	
	if(!(file=fopen("usuario.txt", "r"))){				//Si el archivo no se puede abrir, se cierra el programa
		printf("Error al intentar leer el archivo");
		exit(1);
	}
	//leer del archivo, vaciar hacia un nodo
	while(!feof(file)){
		
		usuario *nuevo = new usuario;
		
		fscanf(file,"%s\t", nuevo->nombre);
		fscanf(file,"%s\n", nuevo->contra);
	
		if(prim==NULL){
			prim=nuevo;
			prim->siguienteb=NULL;
			prim->anteriorb=NULL;
			ult=prim;
		}else{
			ult->siguienteb=nuevo;
			nuevo->siguienteb=NULL;
			nuevo->anteriorb=ult;
			ult=nuevo;
		}
		
	}
	fclose(file);
}

void login(){
	int sigue=1;
	struct admin *auxiliar=NULL;
	struct usuario *aux=NULL;
	int opc,r;
	char nom[20],con[20];
	
	
printf("\t\t\t\t******************************\n");
	printf("\t\t\t\t*\t   BIENVENIDOS       *\n");
	printf("\t\t\t\t*\t1.-ADMINISTRADOR     *\n ");
	printf("\t\t\t\t*\t2.-USUARIO           *\n");
	printf("\t\t\t\t*\t3.-CREAR CUENTA      *\n");
	printf("\t\t\t\t******************************\n");
	scanf("%d",&opc);
	
	if(opc==1){
		do{
			printf("Nombre de usuario: \n");
			scanf("%s",&nom);
			for(auxiliar=primero;auxiliar!=NULL;auxiliar=auxiliar->siguiente){
				if(strcmp(nom,auxiliar->nombre)==0){
					r=1;
					break;
				}
			}
		}while(r==0);
		r=0;
		do{
			printf("Contrasena: \n");
			scanf("%s",&con);
				if(strcmp(con,auxiliar->contra)==0){
					r=1;
				}
		}while(r==0);
		printf("\nWELCOME");
	}
	
	if(opc==2){
		do{
			printf("Nombre de usuario: \n");
			scanf("%s",&nom);
			for(aux=prim;aux!=NULL;aux=aux->siguienteb){
				if(strcmp(nom,aux->nombre)==0){
					r=1;
					break;
				}
			}
		}while(r==0);
		r=0;
		do{
			printf("Contrasena: \n");
			scanf("%s",&con);
				if(strcmp(con,aux->contra)==0){
					r=1;
				}
		}while(r==0);
		printf("\nBIENVENIDO...");
		do{
			menuPasajero();
			sigue=validaEntero("Teclea 1 para escoger otra opcion del menu: ") ;
		}while(sigue==1);
	}

	
	if(opc==3){
		int opc;
	
	printf("\n1.ADMINISTRADOR\n2.USUARIO");
	scanf("%d",&opc);
	if(opc==1){
	int n=0;
	
	if(!(file=fopen("admin.txt", "a+"))){				//Si el archivo no se puede abrir, se cierra el programa
		printf("Error al intentar leer el archivo");
		exit(1);
	}	
		admin *nuevo = new admin;	
			
		if(nuevo==NULL){
			printf("No hay memoria disponible!!");
		}
		
		printf("\nNuevo usuario\n\n");
		printf("\nUsuario: ");
		scanf("%s",&nuevo->nombre);
		printf("\nContrasena: ");
		scanf("%s",&nuevo->contra);
				
		fprintf(file,"\n%s\t", nuevo->nombre);
		fprintf(file,"%s\n", nuevo->contra);

		nuevo->siguiente=NULL;
		nuevo->anterior=NULL;
		
		if(primero==NULL){
			primero=nuevo;
			primero->siguiente=NULL;
			primero->anterior=NULL;
			ultimo=primero;
		}else{
			ultimo->siguiente=nuevo;
			nuevo->siguiente=NULL;
			nuevo->anterior=ultimo;
			ultimo=nuevo;
		}
	fclose(file);
	}
	
	if(opc==2){

	int n=0;
	
	if(!(file=fopen("usuario.txt", "a+"))){				//Si el archivo no se puede abrir, se cierra el programa
		printf("Error al intentar leer el archivo");
		exit(1);
	}	
		usuario *nuevo = new usuario;	
			
		if(nuevo==NULL){
			printf("No hay memoria disponible!!");
		}
		
		printf("\nNuevo usuario\n\n");
		printf("\nUsuario: ");
		scanf("%s",&nuevo->nombre);
		printf("\nContrasena: ");
		scanf("%s",&nuevo->contra);
				
		fprintf(file,"\n%s\t", nuevo->nombre);
		fprintf(file,"%s\n", nuevo->contra);

		nuevo->siguienteb=NULL;
		nuevo->anteriorb=NULL;
		
		if(prim==NULL){
			prim=nuevo;
			prim->siguienteb=NULL;
			prim->anteriorb=NULL;
			ult=prim;
		}else{
			ult->siguienteb=nuevo;
			nuevo->siguienteb=NULL;
			nuevo->anteriorb=ult;
			ult=nuevo;
		}
	fclose(file);
	}
	system("cls");
	login();

	}
}
