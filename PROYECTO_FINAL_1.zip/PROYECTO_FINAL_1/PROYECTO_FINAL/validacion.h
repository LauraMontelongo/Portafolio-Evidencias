float validaFlotante(const char mensaje[]){
	int continuar=0;
	float flotante=0;
	
	do{
		printf("\n%s",mensaje);
		continuar = scanf("%f",&flotante);
		fflush(stdin);
	}while(continuar !=1);
	
	return flotante;
}

int validaEntero(const char mensaje[]){
	int continuar=0;
	int entero=0;
	
	do{
		printf("\n%s",mensaje);
		continuar = scanf("%i",&entero);
		fflush(stdin);
	}while(continuar !=1);//si es 0 el usuario no metio un entero
	return entero;
}

int validaId(const char mensaje[]){
    struct Usuario *auxiliar = primLista;
    int continuar=1,continuar2=0;;
    int id=0,i;
    bool bandera = true;

    do{
        continuar=0;
        auxiliar = primLista;
        id=validaEntero("Id Usuario: ");

        while(auxiliar != NULL){
            if(id==auxiliar->idUsuario){
                continuar = 1;
                break;
            }else{
                continuar = 0;
            }

            auxiliar = auxiliar->sig;
        }


    }while(continuar ==1);

    return id;
}

void validaCadena(const char mensaje[],const char cadena[]){
	bool bandera = true;
	while(bandera){
		printf("\n%s", mensaje);
		scanf("%[^\n]",cadena);
		fflush(stdin);
		if(strlen(cadena)>29){
			continue;
		}else{
			for(int i = 0; i<strlen(cadena); i++){
				if(isalpha(cadena[i]) || cadena[i]==' '){
					if(i== (strlen(cadena)-1)){
						bandera=false;
					}
				}else{
					break;
				}
			}
		}
	}
}
