void menuRutas(MenuRutas *regis,FILE *arch){
 	HANDLE hd = GetStdHandle(STD_OUTPUT_HANDLE);
	
 	if(!(arch=fopen("rutas.txt","a+"))){
		printf("Error al intentar leer el archivo");
		exit(1);
	}
 	
 	while(!feof(arch)){
 		fscanf(arch,"%s\t",regis->nombreRuta);
 		fscanf(arch,"%s\t",regis->paradaRuta);
 		fscanf(arch,"%s\t",regis->horarioRuta);
 		fscanf(arch,"%s\t",regis->destinosRuta);
 		
 		//SetConsoleTextAttribute(hd, 2);
		printf("%s\t",regis->nombreRuta);
		//SetConsoleTextAttribute(hd, 1);
		printf("%s\t",regis->paradaRuta);
		//SetConsoleTextAttribute(hd, 13);
		printf("%s",regis->horarioRuta);
		//SetConsoleTextAttribute(hd, 14);
		printf("%s\t\n",regis->destinosRuta);
		//SetConsoleTextAttribute(hd, 15);
 	}

	fclose(arch);
 }
	

void menuPasajero(){
		FILE *arch=NULL;
		Rutas *primeroR=NULL;
	    int sigue=1,sigue2=2;
    	int opcP;
    	
	    system("cls");
		cout<<"\n\n----- MEN� -----\n";
		cout<<"1.-Ingresar una Ruta";
		cout<<"\n2.- Cambiar Estado";
		cout<<"\n3.- Modificar Horarios";
		cout<<"\n4.- Consultar Horarios";
		cout<<"\n5.- Salir";
		printf("\n\nOpcion: ");
		scanf("%d",&opcP);
		switch(opcP){
			case 1:
				MenuRutas *regis;
				regis=(MenuRutas *)malloc(sizeof(MenuRutas));
				menuRutas(regis,arch);
				agregarLista1();
				mostrarListasE();

				break;
			case 2:
				archivoLecturaRutas(1);
				cambiarEstado();
				archivoEscritura(primeroR,1);
				mostrarListasE();
				break;
				
			case 3:
				system("cls");
				break;
				
			case 4: 
				system("cls");
				break;
				
				
			case 5:
				system("cls");
				printf("HASTA LUEGO :)");
				break;		
		}
}
