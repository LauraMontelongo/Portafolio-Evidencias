Rutas *registro(){
	Rutas *nuevo = new Rutas;
	nuevo->idRuta = validaEntero("Ruta: ");
	cout<<"Parada: ";
	cin>>nuevo->parada;
	cout<<"Destino: ";
	cin>>nuevo->destino;
	cout<<"Hora: ";
	cin>>nuevo->hora;
	cout<<"Dia: ";
	cin>>nuevo->dia;
	nuevo->sigR = NULL;
	return nuevo;
}

Usuario *regis(){//mandar el int id
	Usuario *nuevo = new Usuario;
	registro();
	nuevo->sig=NULL;
	return nuevo;
}

//MUESTRA LA LISTA SIMPLE
void mostrar_lista(Rutas *primeroR){
    int sigue = 1;
    
    struct Rutas *auxiliar = primeroR;
        cout<<endl<<"Mostrando Sus Registros"<<endl;
        cout<<"Ruta "<<setw(10);
		cout<<"Parada "<<setw(10);
        cout<<"Destino "<<setw(10);
        cout<<"Hora "<<setw(10);
        cout<<"Dia "<<setw(10);
        cout<<"Estado "<<endl;
        
    while(auxiliar !=NULL){
        cout<<auxiliar->idRuta<<setw(10);
        cout<<auxiliar->parada<<setw(10);
        cout<<auxiliar->destino<<setw(10);
        cout<<auxiliar->hora<<setw(10);
        cout<<auxiliar->dia<<setw(10);
        cout<<auxiliar->estado<<endl;
        cout<<"\n"<<endl;
        auxiliar = auxiliar->sigR;
    }
    
}

//MUESTRA LAS LISTAS DE LISTAS
void mostrarListas(){
	
	struct Usuario *aux = primLista;
	while(aux!=NULL){
		cout<<aux->lista<<setw(20);
		cout<<aux->sig<<endl;
		aux = aux->sig;
	}
	aux = primLista;
	while(aux!=NULL){ 
		mostrar_lista(aux->lista);//necesito aux lista para modificar
		aux = aux->sig;
	}
}

void agregarFinal(){
	Rutas *nuevo = registro();
	if(ultimoR==NULL){
			primeroR = nuevo;
			ultimoR = nuevo;
	}else{
		nuevo->sigR = primeroR;//ya no toma a Nulo
		primeroR = nuevo;
	}
}

void agregarListasE(){
	//system("cls");
	Usuario *previo, *actual;
	int pos, i=0;
	int agrega=1;
	if(primero==NULL){
		cout<<"No hay elementos en la lista";
		agregarFinal();
	}else{
		do{
			pos=validaEntero("\nId Usuario: ");
			
			if(pos==1){
				//mostrar_lista(actual->lista);
				agregarFinal();
				system("cls");
				mostrar_lista(primeroR);
			}
			else{
				actual = primLista;
				while(actual != NULL && i!= (pos-1)){
					previo=actual;
					actual=actual->sig;
					i++;
				}
				if(actual!=NULL){
					previo->sig=actual->sig;
					if(actual == ultLista) ultLista = previo;
					//mostrar_lista(actual->lista);
					agregarFinal();
					system("cls");
					mostrar_lista(primeroR);
				}
			}
		   printf("Quieres Agregar Otro Registro..1=si/otro=No: ");
		   scanf("%d",&agrega);
		}while(agrega==1);
	}
}

void mostrarListasE(){
	//system("cls");
	Usuario *previo, *actual;
	int pos, i=0;
	if(primero==NULL){
		cout<<"No hay registros previos";
	}else{
		pos=validaEntero("Id Usuario: ");
		
		if(pos==1){
			mostrar_lista(actual->lista);
		}
		else{
			actual = primLista;
			while(actual != NULL && i!= (pos-1)){
				previo=actual;
				actual=actual->sig;
				i++;
			}
			if(actual!=NULL){
				previo->sig=actual->sig;
				if(actual == ultLista) ultLista = previo;
				mostrar_lista(actual->lista);
				
			}
		}
	}
}

//AGREGA LISTAS
void agregarLista(){
	Usuario *nuevo = new Usuario;
	int sigue = 1;
	
	primeroR = NULL;
	ultimoR = NULL;
	
	while(sigue==1){ 
		agregarFinal();
		sigue = validaEntero("Tecla para agregar otro registro: ");//listitas
	}
	
	mostrar_lista(primeroR);
	
	
	nuevo->sig = NULL;
	nuevo->lista = primeroR;
	
	if(primLista==NULL){
		primLista = nuevo;
		ultLista = nuevo;
	}else{
		ultLista->sig=nuevo;
		ultLista = nuevo;
	}
}


void agregarEstado(){
	Rutas *aux = primeroR;
	Rutas *nuevo;
	bool bandera = true;
	int pos = 0;
	int i = 1;
	pos=validaEntero("Ruta - Cambiar Estado: ");
	if(pos==1){
		agregarFinal();
		getchar();
		
	}else{
		while(aux!=NULL){
			if(i==(pos-1)){
				nuevo->estado = validaEntero("Estado: ");
				nuevo->sigR = aux->sigR;
				aux->sigR = nuevo;
				bandera = false;
				break;
			}else{
				aux = aux->sigR;
				i++;
			}
		}
	}
}


//PARA CAMBIAR EL ESTADO
cambiarEstado(){
	
	//system("cls");
	Usuario *previo, *actual;
	struct Rutas *aux = primeroR;
	int pos,rut, i=0;
	if(aux==NULL){
		cout<<"No Cuenta con ning�n registro";
	}else{
		pos=validaEntero("Id Usuario: ");
		
		if(pos==1){
			//mostrar_lista(actual->link);
			agregarEstado();
			mostrar_lista(actual->lista);
		}
		else{
			actual = primLista;
			while(actual != NULL && i!= pos){
				previo=actual;
				actual=actual->sig;
				i++;
			}
			if(actual!=NULL){
				previo->sig=actual->sig;
				if(actual == ultLista) ultLista = previo;
				//mostrar_lista(actual->link);
				agregarEstado();
				
			}
		}
	}
}

void mostrar_lista1(Rutas *primeroR){
	
	struct Rutas *auxiliar = primeroR;
	   auxiliar->estado=1;
        cout<<endl<<"Mostrando Sus Registros"<<endl;
        cout<<"Ruta "<<setw(10);
		cout<<"Parada "<<setw(10);
        cout<<"Destino "<<setw(10);
        cout<<"Hora "<<setw(10);
        cout<<"Dia "<<setw(10);
        cout<<"Estado "<<endl;
        
    while(auxiliar !=NULL){
        cout<<auxiliar->idRuta<<setw(10);
        cout<<auxiliar->parada<<setw(10);
        cout<<auxiliar->destino<<setw(10);
        cout<<auxiliar->hora<<setw(10);
        cout<<auxiliar->dia<<setw(10);
        cout<<auxiliar->estado<<endl;
        cout<<"\n"<<endl;
        auxiliar = auxiliar->sigR;
    }
	
	cout<<endl<<"Primer NODO: "<<primeroR;
	cout<<endl<<"Ultimo NODO: "<<ultimo;
}
void archivoEscritura(Rutas *primeroR,int id){
	Rutas *aux = primeroR;
	char arch[20];
	itoa(id,arch,10);
	strcat(arch,".xls");
	
	ofstream archivo(arch);
	while(aux!=NULL){
		archivo<<aux->idRuta<<"\t";
		archivo<<aux->parada<<"\t";
		archivo<<aux->destino<<"\t";
		archivo<<aux->hora<<"\t";
		archivo<<aux->dia<<"\t";
		archivo<<aux->estado<<endl;
		ultimoR =aux;
		aux=aux->sigR;
	}
	archivo.close();
}

//Listitas
//Cargar la informacion del archivo en la estructura
Rutas *archivoLectura(int id){
    Rutas *primeroR=NULL;
    Rutas *ultimo=NULL;
    Rutas *nuevo=NULL;
    char archivo [20];
    itoa(id,archivo,10);
    strcat(archivo,".xls");
    
    ifstream arch(archivo);
    string linea,c;
    
    cout<<id<<endl;
    
    if(arch.fail()) cerr<<"Error al abrir el archivo"<<endl;
    else{
        while(getline(arch,linea)){
        nuevo = new Rutas;
        stringstream lee(linea);
    
    lee>>nuevo->idRuta;
    getline(lee,c,'\t');
    getline(lee, nuevo->parada,'\t');
    getline(lee, nuevo->destino,'\t');
    getline(lee, nuevo->hora,'\t');
    getline(lee, nuevo->dia,'\t');
    lee>>nuevo->estado;
    getline(lee,c,'\n');
    
    nuevo->sigR=NULL;
    
    if(primeroR==NULL){
        primeroR =nuevo;
        ultimo = nuevo;
    }else{
        ultimo->sigR=nuevo;
        ultimo=nuevo;
            }
        }    
    }
    arch.close();
    return primeroR;
}



void mostrarUsuario(){
	system("cls");
	struct Usuario *aux = primLista;
	cout<<"Ubicacion Nodo: "<<setw(15);
	cout<<"Id lista "<<setw(30);
	cout<<"Listita(Primer Nodo) "<<setw(20);
	cout<<"Siguiente: "<<endl;
	
	while(aux !=NULL){
		cout<<aux<<setw(20);
		cout<<aux->idUsuario<<setw(30);
		cout<<aux->lista<<setw(20);
		cout<<aux->sig<<endl;
		aux = aux->sig;
	}
	cout<<endl<<"Primer LISTA: "<<primLista;
	cout<<endl<<"Ultima LISTA: "<<ultLista<<endl;
	aux = primLista;
	
	while(aux !=NULL){
		mostrar_lista(aux->lista);
		aux = aux->sig;
	}
	
}

void agregarLista1(){
	Usuario *nuevo = new Usuario;
	int sigue = 1;
	
	cout<<"Agregando lista a la LISTA"<<endl;
	nuevo->idUsuario = validaEntero("Dame id Usuario: ");
	
	primeroR =NULL;
	ultimo =NULL;
	
	while(sigue==1){
		agregarFinal();
		sigue = validaEntero("Teclea 1 para agregar registro: ");
	}
	nuevo->lista = primeroR;
	nuevo->sig = NULL;
	archivoEscritura(primeroR,nuevo->idUsuario);
	
	if(primLista ==NULL){
		primLista = nuevo;
		ultLista = nuevo;
	}else{
		ultLista->sig=nuevo;
		ultLista =nuevo;
	}
}

void escrituraLista(){
	Usuario *aux =primLista;
	
	ofstream archivo("UsuarioDeUsuario.xls");
	while(aux!=NULL){
		archivo<<aux->idUsuario<<"\n";
		aux = aux->sig;
	}
	archivo.close();
}
void lecturaLista(){
    Usuario *nuevo=NULL;
    
    ifstream arch("ListaDeUsuario.xls");
    string linea,c;
    
    if(arch.fail()) cerr<<"No se encuentra ninguna lista"<<endl;
    else{
        while(getline(arch,linea)){
            nuevo =new Usuario;
            stringstream lee(linea);
            
            lee>>nuevo->idUsuario;
            getline(lee,c,'\n');
            nuevo->lista=archivoLectura(nuevo->idUsuario);
    
    nuevo->sig=NULL;
    
    if(primLista==NULL){
        primLista=nuevo;
        ultLista=nuevo;
    }else{
        ultLista->sig=nuevo;
        ultLista=nuevo;
            }            
        }
    }
    arch.close();
}
