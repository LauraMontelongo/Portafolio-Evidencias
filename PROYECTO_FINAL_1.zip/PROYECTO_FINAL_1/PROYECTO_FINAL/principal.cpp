#include "librerias.h"

//LAURA IVON MONTELONGO MARTINEZ
int main(){
	FILE *arch=NULL;
	
	//PORTADA
	portada();
	datos();
	system("cls");
	
	SetConsoleCP(1252);
	SetConsoleOutputCP(1252);
	
	system("COLOR 5F");
	
	//PARA LOGIN
	leerarchivo();
	leerarchivo2();
	login();
	
	
	int sigue = 1, opc, sigue2 = 1;
	primeroR = NULL;
	ultimoR = NULL;

	primLista=NULL;
	ultLista=NULL;
	
	while(sigue==1){
		
		agregarLista();
		sigue = validaEntero("Tecla 1 para agregar otra Lista: ");
			
	}
	
	
	return 0;
}
